from test_folder import print_1

# import print_1

print_1.print_func()