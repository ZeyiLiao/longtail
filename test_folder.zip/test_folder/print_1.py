def print_func():
    print(1)